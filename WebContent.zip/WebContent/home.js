/**
 * 
 */
function distance(a,b){
	if (a<b){return b-a;}
	return a-b
}
function main() {
	class particle{
		constructor(x,y,numero,duree,color,trans,dirx,diry){
			this.x=x;this.y=y;this.numero=numero;this.duree=duree;this.color=color;
			this.trans=trans;this.dirx=dirx;this.diry=diry;
		}
		loop(){
			this.x+=this.dirx;
	        this.y+=this.diry;
	        this.duree-=1;
	        ctx.fillStyle=this.color+this.duree*this.trans+')';
			ctx.fillRect(this.x,this.y,10,10);
	        if (this.duree==0){
	            for(var i=0;i<particules.length;i++){
	                if (particules[i].numero>this.numero){
	                	particules[i].numero--;}
	            particules.splice(this.numero)}}
		}
	}
	class ness{
		constructor(x,y){
			this.reinit(x,y)
		}
		reinit(x,y){
			this.x=x;this.y=y;this.tb=0;this.direction=1;
			if (personnage==0){this.costumes=[nespng,nespngg,nesfairpng,nesfairpngg,neshurtpng,neshurtpngg,nesuairpng,nesuairpngg,nesdairpng,nesdairpngg];}
			else if (personnage==1){this.costumes=[marpng,marpngg,marfairpng,marfairpngg,marhurtpng,marhurtpngg,maruairpng,maruairpngg,mardairpng,mardairpngg];}
			else if (personnage==2){this.costumes=[sonpng,sonpngg,sonfairpng,sonfairpngg,sonhurtpng,sonhurtpngg,sonuairpng,sonuairpngg,sondairpng,sondairpngg];}
			else if (personnage==3){this.costumes=[foxpng,foxpngg,foxfairpng,foxfairpngg,foxhurtpng,foxhurtpngg,foxuairpng,foxuairpngg,foxdairpng,foxdairpngg];}
			else if (personnage==4){this.costumes=[bowpng,bowpngg,bowfairpng,bowfairpngg,bowhurtpng,bowhurtpngg,bowuairpng,bowuairpngg,bowdairpng,bowdairpngg];}
			else if (personnage==5){this.costumes=[mewpng,mewpngg,mewfairpng,mewfairpngg,mewhurtpng,mewhurtpngg,mewuairpng,mewuairpngg,mewdairpng,mewdairpngg];}
			this.fair=0;this.hurted=0;this.uair=0;this.dair=0;this.invincibilite=0;this.percent=0;this.hurtx=0;this.hurty=0;
			this.defense=0;
			
		}
		loop(){
			if (this.hurted==0){
			if (this.invincibilite>0){this.invincibilite--;}
			this.vitesse=1;
			if(this.fair!=0){
				this.fair--;
				this.vitesse=0.5;
			}
			else if(this.uair!=0){
				this.uair--;
				this.vitesse=0.3;
				if (personnage==3&&this.uair==15){this.tb=0.8;}
			}
			if(this.dair!=0){
				this.dair--;
				this.vitesse=0.5;
				if (personnage==2&&this.dair>=5){
                    this.tb=0
                    this.vitesse=0.1
                    this.x+=this.direction
                    this.y-=1
                    if (this.y<=1){
                        this.dair=1
                        this.y=1}}
                    else if (personnage==3&&this.dair>=8){
                    this.tb=0
                    this.x+=this.direction*1.5}
                    else if(personnage==4&&this.dair>=8){
                    if (this.y>1){
                        this.tb=-1.2;
                        this.dair=12}
                    else{this.dair=7}}
                    else if(personnage==5&&this.dair==3){
                    this.x+=this.direction*10
                    this.tb=0}
			}
			if (droite==1){this.x+=stats[personnage][3]*this.vitesse;if(this.fair==0){this.direction=1}}
			else if (gauche==1){this.x-=stats[personnage][3]*this.vitesse;if(this.fair==0){this.direction=-1}}
			if (this.y<=1){
				this.tb=1.5;this.y=1;jumpwav.play()
				particules.push(new particle(this.x*20+30,610-this.y*20,particules.length,10,'rgba(134,144,154,',10,2,-2))
				particules.push(new particle(this.x*20+30,610-this.y*20,particules.length,10,'rgba(134,144,154,',10,-2,-2))
				}
			this.y+=this.tb;
			this.tb-=0.05;
			if(this.tb<0 && bas==1){this.y-=0.2}
			if (this.x<-2.5 || this.x>35.5){continuer=0;musique.pause();musique.currentTime = 0;musique.loop=false;return}
			if(this.y>=31){this.y=1.1}
			if (espace==1&&this.fair==0&&this.uair==0&&(this.dair==0||personnage==3)){
				this.fair=0;this.uair=0;this.dair=0;
				if(haut==1){this.uair=stats[personnage][1][0]
				if (personnage==1){this.tb=1.2}
				else if (personnage==3){this.tb=0}}
				else if(bas==1){this.dair=stats[personnage][2][0]}
				else{this.fair=stats[personnage][0][0]}
			}}
			else{
				this.hurted--;
	            this.y+=this.hurty*(0.8-this.defense*0.05+this.hurted*0.04);
	            this.x+=this.hurtx*(0.8-this.defense*0.05+this.hurted*0.04);
			}
			if(espace==1){espace=2}
		}
		afficher(){
			let a=0;
			if (this.fair>=stats[personnage][0][1]){a=2;}
			else if (this.uair>=stats[personnage][1][1]){a=6;}
			else if (this.dair>=stats[personnage][2][1]){a=8;}
			if (this.direction==-1){a++;}
			if (this.invincibilite%2==0){ctx.drawImage(this.costumes[a],this.x*20,560-this.y*20);}
			a=this.percent
			if(a>=12){a=12}
			ctx.fillStyle='rgb(255,'+(255-a*18)+','+(255-a*20)+')';
			ctx.fillRect(340,680,40,20);
			for(var r=0;r<this.defense;r++){
				ctx.drawImage(defenseiconepng,10+r*36,660);
			}
		}
		hurt(x,y,direction,force){
			if (this.invincibilite!=0||this.hurted!=0){return;}
			this.hurted=6+2*force+this.percent;this.hurtx=-1+2*(direction>0);this.hurty=0.2;
			this.fair=0;this.uair=0;this.dair=0;this.tb=0;
			this.invincibilite=20;
			this.percent++;pause=3;
			
		}
	}
	class monster{
		constructor(x,y,direction,numero){
			this.x=x;this.y=y;this.direction=direction;this.numero=numero;
			this.tb=0;this.hurted=0;this.costumes=[monsterpng,monsterpng];this.recompense=1;
			this.hurtx=0;this.hurty=0;this.poid=0;this.force=1;this.adelete=0;
		}
		loop(){
			if (this.y<=1){
				this.y=1;
				if (this.hurted!=0){this.hurty*=-1;}else{this.tb=1.5;}
			}
			if (this.hurted==0){
				this.y+=this.tb;this.x+=this.direction*0.8;this.tb-=0.08;
				for(var i=0;i<monstres.length;i++){
					if(monstres[i].hurted!=0&&distance(this.x,monstres[i].x)<2&&distance(this.y,monstres[i].y)<2){
						this.hurted=monstres[i].hurted+2;this.hurtx=monstres[i].hurtx*1.2;this.hurty=monstres[i].hurty*1.2;pause=2;
						hitwav.currentTime = 0;hitwav.play()
					}
				}
			}
			else{
				this.hurted--;
				this.y+=this.hurty*(0.8+this.hurted*0.04)
	            this.x+=this.hurtx*(0.8+this.hurted*0.04)
	            if (this.hurted%2==0){
	            	particules.push(new particle(this.x*20+30,590-this.y*20,particules.length,10,'rgba(240,195,140,',10,this.hurtx*0.7,this.hurty*0.7))
	            	}
			}
			this.ejection()
		}
		ejection(){
			if (this.hurted!=0&&distance(this.x,xpower)<=distance(this.hurtx*2,0)&&distance(this.y,ypower)<=5&&cptpower==0){cptpower--}
			if (joueur.fair>=stats[personnage][0][1] && distance(this.x,joueur.x+joueur.direction*1.5)<stats[personnage][0][4] && distance(this.y,joueur.y)<stats[personnage][0][5]){
	            this.hurted=14-this.poid
	            this.tb=0
	            this.hurtx=joueur.direction*stats[personnage][0][2];this.hurty=stats[personnage][0][3];
	            this.poid--;hitwav.play();
	            this.x=joueur.x+joueur.direction*(stats[personnage][0][4]+0.5)
	            pause=2
			}
			else if (joueur.uair>=stats[personnage][1][1] && distance(this.x,joueur.x+joueur.direction)<stats[personnage][1][4] && distance(this.y,joueur.y+stats[personnage][1][6])<stats[personnage][1][5]){
	            this.hurted=11-this.poid;hitwav.play();
	            this.tb=0;joueur.tb=0;
	            this.hurtx=joueur.direction*stats[personnage][1][2];this.hurty=stats[personnage][1][3];
	            this.poid-=2;
	            pause=2;
			}
			else if (joueur.dair>=stats[personnage][2][1] && distance(this.x,joueur.x+joueur.direction)<stats[personnage][2][4] && distance(this.y,joueur.y+stats[personnage][2][6])<stats[personnage][2][5]){
	            this.hurted=stats[personnage][2][7]-Math.floor(this.poid/2)
	            this.tb=0;hitwav.play();
	            this.hurtx=joueur.direction*stats[personnage][2][2];this.hurty=stats[personnage][2][3];
	            this.poid-=2;
	            pause=2;if (personnage==2){joueur.dair=5}
			}
			else if(distance(this.x,joueur.x)<1.5&&distance(this.y,joueur.y)<1.5&&this.hurted==0){
				joueur.hurt(this.x,this.y,this.direction,this.force);
			}
			if(this.x<-2||this.x>35){
				if (this.hurted==0){if(this.x<-2){this.direction=distance(0,this.direction);}else{this.direction=distance(0,this.direction)*-1}}
				else{
					this.adelete=1;soulevwav.currentTime = 0;soulevwav.play();
					
				}
			}
			else if(this.y>=28&&this.hurted!=0){
				this.adelete=1;soulevwav.currentTime = 0;soulevwav.play();
			}
		}
		afficher(){
			let a=0;
			if (this.direction<0){a++;}
			ctx.drawImage(this.costumes[a],this.x*20,560-this.y*20);
		}
	}
	class demon extends monster{
		constructor(x,y,direction,numero){
			super(x,y,direction,numero);
			this.costumes=[demonpng,demonpngg];this.recompense=2;
			this.poid=3;this.force=2;this.adelete=0;
		}
		loop(){
			if (this.y<=1){
				this.y=1;
				if (this.hurted!=0){this.hurty*=-1;}else{this.tb=2;}
			}
			if (this.hurted==0){
				this.y+=this.tb;this.x+=this.direction;this.tb-=0.1;
				for(var i=0;i<monstres.length;i++){
					if(monstres[i].hurted!=0&&distance(this.x,monstres[i].x)<2&&distance(this.y,monstres[i].y)<2){
						this.hurted=monstres[i].hurted+2;this.hurtx=monstres[i].hurtx*1.2;this.hurty=monstres[i].hurty*1.2;pause=2;
						hitwav.currentTime = 0;hitwav.play()
					}
				}
			}
			else{
				this.hurted--;
				this.y+=this.hurty*(0.8+this.hurted*0.04)
	            this.x+=this.hurtx*(0.8+this.hurted*0.04)
	            if (this.hurted%2==0){
	            	particules.push(new particle(this.x*20+30,590-this.y*20,particules.length,10,'rgba(200,45,90,',10,this.hurtx*0.7,this.hurty*0.7))
	            	}
			}
			this.ejection()
		}
		ejection(){
			super.ejection()
		}
		afficher(){
			super.afficher()
		}
	}
	class robot extends monster{
		constructor(x,y,direction,numero){
			super(x,y,direction,numero);
			this.costumes=[robotpng,robotpngg];this.recompense=2;
			this.poid=4;this.force=1;this.adelete=0;
		}
		loop(){
			if (this.y<=1){
				this.y=1;
				if (this.hurted!=0){this.hurty*=-1;}else{this.tb=1.5;}
			}
			if (this.hurted==0){
				this.y+=this.tb;this.x+=this.direction;this.tb-=0.06;
				for(var i=0;i<monstres.length;i++){
					if(monstres[i].hurted!=0&&distance(this.x,monstres[i].x)<2&&distance(this.y,monstres[i].y)<2){
						this.hurted=monstres[i].hurted+2;this.hurtx=monstres[i].hurtx*1.2;this.hurty=monstres[i].hurty*1.2;pause=2;
						hitwav.currentTime = 0;hitwav.play()
					}
				}
			}
			else{
				this.hurted--;
				this.y+=this.hurty*(0.8+this.hurted*0.04)
	            this.x+=this.hurtx*(0.8+this.hurted*0.04)
	            if (this.hurted%2==0){
	            	particules.push(new particle(this.x*20+30,590-this.y*20,particules.length,10,'rgba(120,130,140,',10,this.hurtx*0.7,this.hurty*0.7))
	            	}
			}
			this.ejection()
		}
		ejection(){
			super.ejection()
		}
		afficher(){
			super.afficher()
		}
	}
	class ninja extends monster{
		constructor(x,y,direction,numero){
			super(x,y,direction,numero);
			this.costumes=[ninjapng,ninjapngg];this.recompense=2;
			this.poid=3;this.force=2;this.adelete=0;this.cpt=40;
		}
		loop(){
			if (this.y<=1){
				this.y=1;
				if (this.hurted!=0){this.hurty*=-1;}else{this.tb=1.5;}
			}
			if (this.hurted==0){
				this.cpt--;
				this.y+=this.tb;this.tb-=0.06;
				if(this.cpt<=15){this.x+=this.direction*2.5;}
				else{this.x+=this.direction;}
				if(this.cpt==0){this.cpt=90;}
				for(var i=0;i<monstres.length;i++){
					if(monstres[i].hurted!=0&&distance(this.x,monstres[i].x)<2&&distance(this.y,monstres[i].y)<2){
						this.hurted=monstres[i].hurted+2;this.hurtx=monstres[i].hurtx*1.2;this.hurty=monstres[i].hurty*1.2;pause=2;
						hitwav.currentTime = 0;hitwav.play()
					}
				}
			}
			else{
				this.hurted--;
				this.y+=this.hurty*(0.8+this.hurted*0.04)
	            this.x+=this.hurtx*(0.8+this.hurted*0.04)
	            if (this.hurted%2==0){
	            	particules.push(new particle(this.x*20+30,590-this.y*20,particules.length,10,'rgba(20,130,95,',10,this.hurtx*0.7,this.hurty*0.7))
	            	}
			}
			this.ejection()
		}
		ejection(){
			super.ejection()
		}
		afficher(){
			super.afficher()
		}
	}
	class knight extends monster{
		constructor(x,y,direction,numero){
			super(x,y,direction,numero);
			this.costumes=[knightpng,knightpngg];this.recompense=2;
			this.poid=4;this.force=1;this.adelete=0;this.cpt=40;
		}
		loop(){
			if (this.y<=1){
				this.y=1;
				if (this.hurted!=0){this.hurty*=-1;}else{this.tb=1.5;}
			}
			if (this.hurted==0){
				this.cpt--;
				this.y+=this.tb;this.tb-=0.06;
				if(this.cpt<=15){this.tb+=0.05}
				this.x+=this.direction;
				if(this.cpt==0){this.cpt=80;}
				for(var i=0;i<monstres.length;i++){
					if(monstres[i].hurted!=0&&distance(this.x,monstres[i].x)<2&&distance(this.y,monstres[i].y)<2){
						this.hurted=monstres[i].hurted+2;this.hurtx=monstres[i].hurtx*1.2;this.hurty=monstres[i].hurty*1.2;pause=2;
						hitwav.currentTime = 0;hitwav.play()
					}
				}
			}
			else{
				this.hurted--;
				this.y+=this.hurty*(0.8+this.hurted*0.04)
	            this.x+=this.hurtx*(0.8+this.hurted*0.04)
	            if (this.hurted%2==0){
	            	particules.push(new particle(this.x*20+30,590-this.y*20,particules.length,10,'rgba(30,140,190,',10,this.hurtx*0.7,this.hurty*0.7))
	            	}
			}
			this.ejection()
		}
		ejection(){
			super.ejection()
		}
		afficher(){
			super.afficher()
		}
	}
	class king extends monster{
		constructor(x,y,direction,numero){
			super(x,y,direction*1.2,numero);
			this.costumes=[kingpng,kingpngg];this.recompense=2;
			this.poid=5;this.force=3;this.adelete=0;
		}
		loop(){
			if (this.y<=1){
				this.y=1;
				if (this.hurted!=0){this.hurty*=-1;}else{this.tb=2.5;}
			}
			if (this.hurted==0){
				this.y+=this.tb;this.x+=this.direction;this.tb-=0.15;
				for(var i=0;i<monstres.length;i++){
					if(monstres[i].hurted!=0&&distance(this.x,monstres[i].x)<2&&distance(this.y,monstres[i].y)<2){
						this.hurted=monstres[i].hurted+2;this.hurtx=monstres[i].hurtx*1.2;this.hurty=monstres[i].hurty*1.2;pause=2;
						hitwav.currentTime = 0;hitwav.play()
					}
				}
			}
			else{
				this.hurted--;
				this.y+=this.hurty*(0.8+this.hurted*0.04)
	            this.x+=this.hurtx*(0.8+this.hurted*0.04)
	            if (this.hurted%2==0){
	            	particules.push(new particle(this.x*20+30,590-this.y*20,particules.length,10,'rgba(155,215,215,',10,this.hurtx*0.7,this.hurty*0.7))
	            	}
			}
			this.ejection()
		}
		ejection(){
			super.ejection()
		}
		afficher(){
			super.afficher()
		}
	}
	function affichtt(){
		ctx.fillStyle="black";
		ctx.fillRect(0, 0, 720,720);
		ctx.fillStyle="white";
		if (cptvag==0){ctx.fillText(scoreaff, 320, 70);}
		else if(cptvag%2==0){ctx.fillText("Phase "+vague, 280, 70);}
		ctx.drawImage(ground,0,600)
		for (var j = 0; j < particules.length; j++){
			particules[j].loop();
		}
		for (var i = 0; i < monstres.length; i++){monstres[i].afficher()}
		joueur.afficher()
		if (cptpower<=0){ctx.drawImage(poweruppng,xpower*20,560-ypower*20)}
		
	}
	function loop(){
		if (pause!=0){
			pause--;return;
		}
		if (continuer==0){
			ctx.drawImage(youlostpng,0,0);
			ctx.fillStyle="white";
			ctx.fillText(scoreaff, 330, 300);
			if (espace==1){continuer=3;espace=2;gold+=scoreaff;}}
		else if(continuer==3){
			ctx.fillStyle="black";
			ctx.fillRect(0, 0, 720,720);
			ctx.fillStyle="white";
			ctx.fillText(gold, 320, 70);
			ctx.drawImage(icones[personnage],320,240)
			if (prix[personnage]==0){ctx.drawImage(playpng,300,440)}
			else if(prix[personnage]<=gold){
				ctx.drawImage(buypng,300,440);
				ctx.font = '28px serif';
				ctx.fillText(prix[personnage], 330,465);
			}
			else{
				ctx.drawImage(poorpng,300,440);
				ctx.font = '28px serif';
				ctx.fillText(prix[personnage], 330,465);
			}
			if (espace==1){if(prix[personnage]==0){continuer=2;espace=2}
			else if(prix[personnage]<=gold){gold-=prix[personnage];prix[personnage]=0;espace=2;}
			else{}
			}
			else if(droite==1){personnage=(personnage+1)%6;droite=2}
			else if(gauche==1){personnage=(personnage+5)%6;gauche=2}
			ctx.font = '48px serif';
		}
		else if(continuer==2){joueur.reinit(18,1);monstres=[];score=0;scoreaff=0;continuer=1;vague=0;cptvague=60;cpt=60;musique.play();musique.loop=true;particules=[];
		monstrestypes=[monster,[demon,robot][Math.floor(Math.random()*2)],[knight,ninja][Math.floor(Math.random()*2)],king];xpower=0;ypower=0;cptpower=200;dirpower=0;}
		else if(continuer==1){
		if(pausee==1){return;}
		if (score+monstres.length>=vague*30){
			if(monstres.length==0){
				scoreaff+=vague*10;
                vague+=1;cptvag=60;
                joueur.percent=Math.floor(joueur.percent/2)}}
		else if(cptvag!=0){cptvag--;}
		else if(monstres.length<=6){cpt--;if(monstres.length==0&&cpt>=10){cpt-=3;}}
		if(cptpower==-1){
			xpower+=dirpower*0.4;
			if (xpower<-1.5||xpower>35.5){cptpower=250}
			else if(distance(joueur.x,xpower)<=4&&distance(joueur.y,ypower)<=4){
                cptpower=250;
                if (joueur.defense<=8){joueur.defense++}
                else{
                    scoreaff+=15;
                    goldgainwav.play()}}}
		else if(cptpower>=2){cptpower--;}
		else if(cptpower!=0){
            cote=Math.floor(Math.random()*2);
            xpower=33*cote;
            ypower=Math.floor(Math.random()*8)+14;if(score<=15&&ypower>17){ypower=17}
            dirpower=(-1+cote*2)*-1;
            cptpower=0}
		
		if (cpt<=0){
			cpt=Math.floor(Math.random()*5)+68-Math.floor(score/3);
			cote=Math.floor(Math.random()*2);
			for(i=0;i<vague;i++){
				if(score+monstres.length>=vague*30){break;}
			typ=Math.floor((Math.random()*20+score)/25);
			if (typ>3){typ=3}
			monstres.push(new monstrestypes[typ](-1+cote*36,Math.floor(Math.random()*5)+1,(1-cote*2)/(Math.floor(Math.random()*3)+3),monstres.length))
			cote=(cote+1)%2;cpt+=typ*20;}
		}
		joueur.loop();
		for (var i = 0; i < monstres.length; i++){
			if (monstres[i].adelete){
				score++;scoreaff+=monstres[i].recompense;
				for(var r=0;r<monstres.length;r++){
					if(monstres[r].numero>monstres[i].numero){monstres[r].numero--;}
				}
				monstres.splice(monstres[i].numero,1);}
		else{monstres[i].loop()}}
		
		affichtt();}
		
	}
      var canvas = document.getElementById("canvas");
      if (canvas.getContext) {
        var ctx = canvas.getContext("2d");
        var musique = document.querySelector('#musique');
        var hitwav = document.querySelector('#hitwav');
        var soulevwav = document.querySelector('#soulevwav');
        var jumpwav = document.querySelector('#jumpwav');
        var goldgainwav = document.querySelector('#goldgainwav');
        var ground = new Image();
        var youlostpng = new Image();youlostpng.src = 'ressource/you lost.png';
        var playpng = new Image();playpng.src = 'ressource/play.png';
        var buypng = new Image();buypng.src = 'ressource/buy.png';
        var poorpng = new Image();poorpng.src = 'ressource/poor.png';
        var poweruppng = new Image();poweruppng.src = 'ressource/powerup.png';
        var defenseiconepng = new Image();defenseiconepng.src = 'ressource/defenseicone.png';
        var nespng = new Image();nespng.src = 'ressource/nes.png';
        var nespngg = new Image();nespngg.src = 'ressource/nesg.png';
        var nesfairpng = new Image();nesfairpng.src = 'ressource/nesfair.png';
        var nesfairpngg = new Image();nesfairpngg.src = 'ressource/nesfairg.png';
        var neshurtpng = new Image();neshurtpng.src = 'ressource/neshurt.png';
        var neshurtpngg = new Image();neshurtpngg.src = 'ressource/neshurtg.png';
        var nesuairpng = new Image();nesuairpng.src = 'ressource/nesuair.png';
        var nesuairpngg = new Image();nesuairpngg.src = 'ressource/nesuairg.png';
        var nesdairpng = new Image();nesdairpng.src = 'ressource/nesdair.png';
        var nesdairpngg = new Image();nesdairpngg.src = 'ressource/nesdairg.png';
        var marpng = new Image();marpng.src = 'ressource/mar.png';
        var marpngg = new Image();marpngg.src = 'ressource/marg.png';
        var marfairpng = new Image();marfairpng.src = 'ressource/marfair.png';
        var marfairpngg = new Image();marfairpngg.src = 'ressource/marfairg.png';
        var marhurtpng = new Image();marhurtpng.src = 'ressource/marhurt.png';
        var marhurtpngg = new Image();marhurtpngg.src = 'ressource/marhurtg.png';
        var maruairpng = new Image();maruairpng.src = 'ressource/maruair.png';
        var maruairpngg = new Image();maruairpngg.src = 'ressource/maruairg.png';
        var mardairpng = new Image();mardairpng.src = 'ressource/mardair.png';
        var mardairpngg = new Image();mardairpngg.src = 'ressource/mardairg.png'
        var monsterpng = new Image();monsterpng.src = 'ressource/monster.png';
        var sonpng = new Image();sonpng.src = 'ressource/son.png';
        var sonpngg = new Image();sonpngg.src = 'ressource/song.png';
        var sonfairpng = new Image();sonfairpng.src = 'ressource/sonfair.png';
        var sonfairpngg = new Image();sonfairpngg.src = 'ressource/sonfairg.png';
        var sonhurtpng = new Image();sonhurtpng.src = 'ressource/sonhurt.png';
        var sonhurtpngg = new Image();sonhurtpngg.src = 'ressource/sonhurtg.png';
        var sonuairpng = new Image();sonuairpng.src = 'ressource/sonuair.png';
        var sonuairpngg = new Image();sonuairpngg.src = 'ressource/sonuairg.png';
        var sondairpng = new Image();sondairpng.src = 'ressource/sondair.png';
        var sondairpngg = new Image();sondairpngg.src = 'ressource/sondairg.png';
        var foxpng = new Image();foxpng.src = 'ressource/fox.png';
        var foxpngg = new Image();foxpngg.src = 'ressource/foxg.png';
        var foxfairpng = new Image();foxfairpng.src = 'ressource/foxfair.png';
        var foxfairpngg = new Image();foxfairpngg.src = 'ressource/foxfairg.png';
        var foxhurtpng = new Image();foxhurtpng.src = 'ressource/foxhurt.png';
        var foxhurtpngg = new Image();foxhurtpngg.src = 'ressource/foxhurtg.png';
        var foxuairpng = new Image();foxuairpng.src = 'ressource/foxuair.png';
        var foxuairpngg = new Image();foxuairpngg.src = 'ressource/foxuairg.png';
        var foxdairpng = new Image();foxdairpng.src = 'ressource/foxdair.png';
        var foxdairpngg = new Image();foxdairpngg.src = 'ressource/foxdairg.png';
        var bowpng = new Image();bowpng.src = 'ressource/bow.png';
        var bowpngg = new Image();bowpngg.src = 'ressource/bowg.png';
        var bowfairpng = new Image();bowfairpng.src = 'ressource/bowfair.png';
        var bowfairpngg = new Image();bowfairpngg.src = 'ressource/bowfairg.png';
        var bowhurtpng = new Image();bowhurtpng.src = 'ressource/bowhurt.png';
        var bowhurtpngg = new Image();bowhurtpngg.src = 'ressource/bowhurtg.png';
        var bowuairpng = new Image();bowuairpng.src = 'ressource/bowuair.png';
        var bowuairpngg = new Image();bowuairpngg.src = 'ressource/bowuairg.png';
        var bowdairpng = new Image();bowdairpng.src = 'ressource/bowdair.png';
        var bowdairpngg = new Image();bowdairpngg.src = 'ressource/bowdairg.png';
        var mewpng = new Image();mewpng.src = 'ressource/mew.png';
        var mewpngg = new Image();mewpngg.src = 'ressource/mewg.png';
        var mewfairpng = new Image();mewfairpng.src = 'ressource/mewfair.png';
        var mewfairpngg = new Image();mewfairpngg.src = 'ressource/mewfairg.png';
        var mewhurtpng = new Image();mewhurtpng.src = 'ressource/mewhurt.png';
        var mewhurtpngg = new Image();mewhurtpngg.src = 'ressource/mewhurtg.png';
        var mewuairpng = new Image();mewuairpng.src = 'ressource/mewuair.png';
        var mewuairpngg = new Image();mewuairpngg.src = 'ressource/mewuairg.png';
        var mewdairpng = new Image();mewdairpng.src = 'ressource/mewdair.png';
        var mewdairpngg = new Image();mewdairpngg.src = 'ressource/mewdairg.png';
        var monsterpng = new Image();monsterpng.src = 'ressource/monster.png';
        var demonpng = new Image();demonpng.src = 'ressource/demon.png';
        var demonpngg = new Image();demonpngg.src = 'ressource/demong.png';
        var robotpng = new Image();robotpng.src = 'ressource/robot.png';
        var robotpngg = new Image();robotpngg.src = 'ressource/robotg.png';
        var knightpng = new Image();knightpng.src = 'ressource/knight.png';
        var knightpngg = new Image();knightpngg.src = 'ressource/knightg.png';
        var ninjapng = new Image();ninjapng.src = 'ressource/ninja.png';
        var ninjapngg = new Image();ninjapngg.src = 'ressource/ninjag.png';
        var kingpng = new Image();kingpng.src = 'ressource/king.png';
        var kingpngg = new Image();kingpngg.src = 'ressource/kingg.png';
        ground.src = 'ressource/ground.png';
        pausee=0;p=0;
        document.addEventListener('keydown', logKey);
        document.addEventListener('keyup', unlogKey);
        droite=0;gauche=0;haut=0;bas=0;espace=0;
        ctx.font = '48px serif';
        var stats=[[[15,6,1.5,0.1,1.5,2],[12,4,0,1.1,1.5,2,1.5],[11,6,0.6,0.6,1.5,2,-1.5,12],0.5],
        	[[15,8,1.2,0,2.2,2.5],[20,10,0.2,1.2,1.5,2.2,2],[11,6,0.5,0.8,2,2.6,-1,12],0.5],
        	[[16,5,1.3,0.1,1.6,1.8],[10,3,0,0.8,1.5,2,1.5],[12,5,1.2,-1.2,2.5,2.5,0,14],0.6],
        	[[14,6,1.5,0.1,1.4,2.2],[18,10,0,1.5,2,3,0],[15,8,1.2,0.6,2,1.5,0,10],0.5],
        	[[18,8,1.7,0.15,1.3,2.2],[15,6,0.2,1.4,1.5,2,1.5],[11,8,0.4,-2.2,1.5,2,-1.5,14],0.45],
        	[[15,5,1.6,0.15,1.5,2],[12,4,0.2,1.2,1.5,2,1.7],[6,2,0.4,0.4,2,2,0,10],0.55]];
        function logKey(e) {
        	  if(e.code=="ArrowRight"&&droite==0){droite=1}
        	  else if(e.code=="ArrowLeft"&&gauche==0){gauche=1}
        	  else if(e.code=="ArrowUp"){haut=1}
        	  else if(e.code=="ArrowDown"){bas=1}
        	  else if(e.code=="Space"&&espace==0){espace=1}
        	  else if(e.code=="KeyP"&&p==0){p=1;pausee=(pausee+1)%2;
        	  if(pausee==1){musique.pause()}else{musique.play()}}
        	}
        function unlogKey(e){
        	if(e.code=="ArrowRight"){droite=0}
        	else if(e.code=="ArrowLeft"){gauche=0}
        	else if(e.code=="ArrowUp"){haut=0}
        	else if(e.code=="ArrowDown"){bas=0}
        	else if(e.code=="Space"){espace=0}
        	else if(e.code=="KeyP"){p=0}
        }
        xpower=0;ypower=0;cptpower=200;dirpower=0;particules=[];
        icones=[nespng,marpng,sonpng,foxpng,bowpng,mewpng];prix=[0,0,50,0,50,200];
        personnage=1;var joueur=new ness(18,1);continuer=2;cpt=6;var monstres=[];pause=0;score=0;scoreaff=0;gold=0;
        ground.onload = function(){var timer=setInterval(loop,33);}
        
      }}
